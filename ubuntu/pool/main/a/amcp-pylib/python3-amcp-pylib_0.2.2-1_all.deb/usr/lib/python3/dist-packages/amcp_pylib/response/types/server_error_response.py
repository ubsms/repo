from ..response_base import ResponseBase as ResponseBase


class ServerErrorResponse(ResponseBase):
    pass
