from ..response_base import ResponseBase as ResponseBase


class InfoResponse(ResponseBase):
    pass
