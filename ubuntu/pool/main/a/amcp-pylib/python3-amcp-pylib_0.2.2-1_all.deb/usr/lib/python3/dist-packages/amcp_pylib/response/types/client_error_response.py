from ..response_base import ResponseBase as ResponseBase


class ClientErrorResponse(ResponseBase):
    pass
